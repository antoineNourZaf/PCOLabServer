#include "readerwriterlock.h"

ReaderWriterLock::ReaderWriterLock()
{

}

void ReaderWriterLock::lockReading() {

}

void ReaderWriterLock::unlockReading() {

}

void ReaderWriterLock::lockWriting() {

}

void ReaderWriterLock::unlockWriting() {
    
}
